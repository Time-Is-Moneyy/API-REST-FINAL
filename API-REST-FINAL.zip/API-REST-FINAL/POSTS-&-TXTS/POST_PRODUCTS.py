                                           # POST DOS PRODUTOS #

import requests

data = {}
with open('PRODUTOS.txt', 'r') as arquivo:

    arq = arquivo.readlines()
    for linha in arq:
        print(linha)
        valor = name, price, stock=linha.split(",")
        if len(valor) == 3:
            name, price, stock = valor
            data["name"] = name
            data["price"] =price
            data["stock"] = stock
        print(data)

        response = requests.post('http://127.0.0.1:5000/products', json=data)
        if response.status_code == 201:
            task = response.json()
            print(task)
        else:
            print('Error:', response.text)
