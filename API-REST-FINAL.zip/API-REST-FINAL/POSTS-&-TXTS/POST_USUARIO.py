                                         # POST DOS USUÁRIOS #

import requests

data = {}
with open('CLIENTES.txt', 'r') as arquivo:

    arq = arquivo.readlines()
    for linha in arq:
        print(linha)
        valor = name, email, age=linha.split(",")
        if len(valor) == 3:
            name, email, age = valor
            data["name"] = name
            data["email"] =email
            data["age"] = age
        print(data)

        response = requests.post('http://127.0.0.1:5000/users', json=data)
        if response.status_code == 201:
            task = response.json()
            print(task)
        else:
            print('Error:', response.text)
