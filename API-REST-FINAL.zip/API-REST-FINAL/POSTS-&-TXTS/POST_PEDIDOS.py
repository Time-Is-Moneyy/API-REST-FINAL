                                      # POST DOS PEDIDOS #

def get_user_id(email):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE email = ?", (email,))
    result = cursor.fetchone()
    conn.close()
    if result:
        return result[0]
    else:
        return None

with open('PEDIDOS.txt', 'r') as arquivo:
    arq = arquivo.readlines()
    for linha in arq:
        print(linha)
        idu, descricao, status = linha.strip().split(",")
        user_id = get_user_id(idu)  # Obter o ID do usuário pelo email
        if user_id is not None:
            data = {
                "idu": user_id,
                "descricao": descricao,
                "status": status
            }
            print(data)

            response = requests.post('http://127.0.0.1:5000/pedidos', json=data)
            if response.status_code == 201:
                task = response.json()
                print(task)
            else:
                print('Error:', response.text)
        else:
            print(f'Usuário com email "{idu}" não encontrado no banco de dados')
