import requests

data = {
    'title': 'Comprar leite',
    'description': 'Comprar leite no supermercado'
}

response = requests.post('http://localhost:5000/tasks', json=data)

if response.status_code == 201:
    task = response.json()
    print(task)
else:
    print('Error:', response.text)