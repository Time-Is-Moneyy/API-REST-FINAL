from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

            # MODELO DOS PRODUTOS #
class ProductModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return f'<Product {self.name}>'

               # MODELO TASK #
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(500), nullable=True)
    done = db.Column(db.Boolean, nullable=False, default=False)

    def __repr__(self):
        return f'<Task {self.name}>'

             # MODELO DOS USUÁRIOS #
class UserModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer, nullable=True)

    def __repr__(self):
        return f'<User {self.name}>'

             # MODELO DE PEDIDOS #
class PedidoModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    idu = db.Column(db.Float(20), nullable=False)
    descricao = db.Column(db.String(500), nullable=False)
    status = db.Column(db.String(30), nullable=True)

    def __repr__(self):
        return f'<Pedido {self.name}>'

               # MODELO ORDER #
#class OrderModel(db.Model):
    #id = db.Column(db.Integer, primary_key=True)
    #user_id = db.Column(db.Integer, db.ForeignKey('user_model.id'))
    #user = db.relationship("UserModel")
    #description = db.Column(db.String(500), nullable=True)
    #status = db.Column(db.String(20), nullable=False)
    #products = db.relationship('ProductModel', secondary=order_product_association, backref=db.backref('orders', lazy='dynamic'))

    #def __repr__(self):
        #return f'<Order {self.id}>'

# Tabela de associação para a relação Many-to-Many entre OrderModel e ProductModel
order_product_association = db.Table('order_product_association',
    db.Column('order_id', db.Integer, db.ForeignKey('order_model.id')),
    db.Column('product_id', db.Integer, db.ForeignKey('product_model.id'))
)